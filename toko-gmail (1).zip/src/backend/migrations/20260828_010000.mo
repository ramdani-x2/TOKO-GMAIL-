import Map "mo:core/Map";
import Principal "mo:core/Principal";

module {
  type UserRole = {
    #admin;
    #user;
    #guest;
  };

  type AccessControlState = {
    var adminAssigned : Bool;
    userRoles : Map.Map<Principal, UserRole>;
  };

  type ProductType = {
    #fresh;
    #bekas;
  };

  type Product = {
    productType : ProductType;
    price : Nat;
  };

  type GmailAccount = {
    id : Nat;
    productType : ProductType;
    email : Text;
    password : Text;
    var delivered : Bool;
  };

  type OrderStatus = {
    #pendingPayment;
    #paid;
    #delivered;
  };

  type Order = {
    orderNumber : Text;
    buyerName : Text;
    buyerContact : Text;
    productType : ProductType;
    quantity : Nat;
    totalPrice : Nat;
    var status : OrderStatus;
    var deliveredAccount : ?Text;
    createdAt : Int;
  };

  type OldQrisConfig = {
    var code : Text;
  };

  type NewQrisConfig = {
    var code : Text;
    var image : ?Blob;
  };

  type OldActor = {
    accessControlState : AccessControlState;
    products : Map.Map<ProductType, Product>;
    stock : Map.Map<ProductType, [GmailAccount]>;
    orders : Map.Map<Text, Order>;
    qrisConfig : OldQrisConfig;
  };

  type NewActor = {
    accessControlState : AccessControlState;
    products : Map.Map<ProductType, Product>;
    stock : Map.Map<ProductType, [GmailAccount]>;
    orders : Map.Map<Text, Order>;
    qrisConfig : NewQrisConfig;
  };

  public func migration(old : OldActor) : NewActor {
    {
      accessControlState = old.accessControlState;
      products = old.products;
      stock = old.stock;
      orders = old.orders;
      qrisConfig = {
        var code = old.qrisConfig.code;
        var image = null;
      };
    };
  };
};
