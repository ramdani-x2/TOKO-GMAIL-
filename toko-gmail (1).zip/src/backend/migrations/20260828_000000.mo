import Map "mo:core/Map";
import Principal "mo:core/Principal";

module {
  type UserRole = {
    #admin;
    #user;
    #guest;
  };

  type AccessControlState = {
    var adminAssigned : Bool;
    userRoles : Map.Map<Principal, UserRole>;
  };

  type ProductType = {
    #fresh;
    #bekas;
  };

  type Product = {
    productType : ProductType;
    price : Nat;
  };

  type GmailAccount = {
    id : Nat;
    productType : ProductType;
    email : Text;
    password : Text;
    var delivered : Bool;
  };

  type OrderStatus = {
    #pendingPayment;
    #paid;
    #delivered;
  };

  type Order = {
    orderNumber : Text;
    buyerName : Text;
    buyerContact : Text;
    productType : ProductType;
    quantity : Nat;
    totalPrice : Nat;
    var status : OrderStatus;
    var deliveredAccount : ?Text;
    createdAt : Int;
  };

  type QrisConfig = {
    var code : Text;
  };

  type OldActor = {};

  type NewActor = {
    accessControlState : AccessControlState;
    products : Map.Map<ProductType, Product>;
    stock : Map.Map<ProductType, [GmailAccount]>;
    orders : Map.Map<Text, Order>;
    qrisConfig : QrisConfig;
  };

  func compareProductType(a : ProductType, b : ProductType) : { #less; #equal; #greater } {
    switch (a, b) {
      case (#fresh, #fresh) #equal;
      case (#fresh, #bekas) #less;
      case (#bekas, #fresh) #greater;
      case (#bekas, #bekas) #equal;
    };
  };

  public func migration(_old : OldActor) : NewActor {
    let products = Map.empty<ProductType, Product>();
    products.add(compareProductType, #fresh, { productType = #fresh; price = 6000 });
    products.add(compareProductType, #bekas, { productType = #bekas; price = 3000 });
    {
      accessControlState = {
        var adminAssigned = false;
        userRoles = Map.empty();
      };
      products;
      stock = Map.empty();
      orders = Map.empty();
      qrisConfig = { var code = "" };
    };
  };
};
