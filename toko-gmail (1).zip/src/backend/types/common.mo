import Storage "mo:caffeineai-object-storage/Storage";

module {
  // Product types sold by the storefront.
  public type ProductType = {
    #fresh; // Gmail Fresh — Rp6.000
    #bekas; // Gmail Bekas — Rp3.000
  };

  // Fixed product definition with its price.
  public type Product = {
    productType : ProductType;
    price : Nat;
  };

  // A single Gmail account held in stock, awaiting delivery.
  public type GmailAccount = {
    id : Nat;
    productType : ProductType;
    email : Text;
    password : Text;
    var delivered : Bool;
  };

  // Lifecycle of an order.
  public type OrderStatus = {
    #pendingPayment;
    #paid;
    #delivered;
  };

  // A buyer order with a unique order number.
  public type Order = {
    orderNumber : Text;
    buyerName : Text;
    buyerContact : Text;
    productType : ProductType;
    quantity : Nat;
    totalPrice : Nat;
    var status : OrderStatus;
    var deliveredAccount : ?Text;
    createdAt : Int;
  };

  // Admin-configured QRIS payment code and optional uploaded QRIS image.
  public type QrisConfig = {
    var code : Text;
    var image : ?Storage.ExternalBlob;
  };
};
