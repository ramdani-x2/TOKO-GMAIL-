import Types "../types/common";

module {
  // Shared (serializable) view of an order for the public API.
  public type OrderView = {
    orderNumber : Text;
    buyerName : Text;
    buyerContact : Text;
    productType : Types.ProductType;
    quantity : Nat;
    totalPrice : Nat;
    status : Types.OrderStatus;
    deliveredAccount : ?Text;
    createdAt : Int;
  };

  // Shared (serializable) view of a Gmail account for the public API.
  public type GmailAccountView = {
    id : Nat;
    productType : Types.ProductType;
    email : Text;
    password : Text;
    delivered : Bool;
  };

  // Ordering for ProductType, used as the implicit Map comparator.
  public func compare(a : Types.ProductType, b : Types.ProductType) : { #less; #equal; #greater } {
    switch (a, b) {
      case (#fresh, #fresh) #equal;
      case (#fresh, #bekas) #less;
      case (#bekas, #fresh) #greater;
      case (#bekas, #bekas) #equal;
    };
  };
};
