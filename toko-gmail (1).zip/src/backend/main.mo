import AccessControl "mo:caffeineai-authorization/access-control";
import MixinAuthorization "mo:caffeineai-authorization/MixinAuthorization";
import MixinObjectStorage "mo:caffeineai-object-storage/Mixin";
import OQL "mo:caffeineai-oql";
import Expose "mo:caffeineai-oql/Expose";
import Entity "mo:caffeineai-oql/Entity";
import TextValue "mo:caffeineai-oql/TextValue";
import NatValue "mo:caffeineai-oql/NatValue";
import IntValue "mo:caffeineai-oql/IntValue";
import BoolValue "mo:caffeineai-oql/BoolValue";
import Map "mo:core/Map";
import Storage "mo:caffeineai-object-storage/Storage";
import Types "types/common";
import StoreApi "mixins/store-api";

actor {
  let accessControlState : AccessControl.AccessControlState;
  include MixinAuthorization(accessControlState, null);
  include MixinObjectStorage();

  // Stable state for the Gmail storefront.
  let products : Map.Map<Types.ProductType, Types.Product>;
  let stock : Map.Map<Types.ProductType, [Types.GmailAccount]>;
  let orders : Map.Map<Text, Types.Order>;
  let qrisConfig : Types.QrisConfig;

  include StoreApi(accessControlState, products, stock, orders, qrisConfig);

  // Flatten all Gmail accounts across every product type into a single list.
  func allAccounts() : [Types.GmailAccount] {
    var accs : [Types.GmailAccount] = [];
    for ((_, accounts) in stock.entries()) {
      accs := accs.concat(accounts);
    };
    accs
  };

  include Expose({
    entities = [
      OQL.Entity.manual<Types.Product>("product", func () = products.values(), "Product", "productType")
        .sample({ productType = #fresh; price = 0 })
        .payload("productType", func p = (switch (p.productType) { case (#fresh) "fresh"; case (#bekas) "bekas" }))
        .payload("price", func p = p.price)
        .public_()
        .build(),
      OQL.Entity.manual<Types.Order>("order", func () = orders.values(), "Order", "orderNumber")
        .sample({ orderNumber = ""; buyerName = ""; buyerContact = ""; productType = #fresh; quantity = 0; totalPrice = 0; var status = #pendingPayment; var deliveredAccount = null; createdAt = 0 } : Types.Order)
        .payload("orderNumber", func o = o.orderNumber)
        .payload("buyerName", func o = o.buyerName)
        .payload("buyerContact", func o = o.buyerContact)
        .payload("productType", func o = (switch (o.productType) { case (#fresh) "fresh"; case (#bekas) "bekas" }))
        .payload("quantity", func o = o.quantity)
        .payload("totalPrice", func o = o.totalPrice)
        .payload("status", func o = (switch (o.status) { case (#pendingPayment) "pendingPayment"; case (#paid) "paid"; case (#delivered) "delivered" }))
        .payload("deliveredAccount", func o = (switch (o.deliveredAccount) { case (?e) e; case null "" }))
        .payload("createdAt", func o = o.createdAt)
        .controllerOnly()
        .build(),
      OQL.Entity.manual<Types.GmailAccount>("stock", func () = allAccounts().values(), "GmailAccount", "id")
        .sample({ id = 0; productType = #fresh; email = ""; password = ""; var delivered = false })
        .payload("id", func a = a.id)
        .payload("productType", func a = (switch (a.productType) { case (#fresh) "fresh"; case (#bekas) "bekas" }))
        .payload("email", func a = a.email)
        .payload("delivered", func a = a.delivered)
        .controllerOnly()
        .build(),
      OQL.Entity.manual<Types.QrisConfig>("qrisConfig", func () = [qrisConfig].values(), "QrisConfig", "id")
        .sample({ var code = ""; var image = null : ?Storage.ExternalBlob })
        .payload("id", func _ = "config")
        .payload("code", func c = c.code)
        .controllerOnly()
        .build(),
    ];
  });
};
