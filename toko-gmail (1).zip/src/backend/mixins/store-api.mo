import Map "mo:core/Map";
import Text "mo:core/Text";
import Runtime "mo:core/Runtime";
import AccessControl "mo:caffeineai-authorization/access-control";
import Storage "mo:caffeineai-object-storage/Storage";
import Types "../types/common";
import StoreTypes "../types/store";
import StoreLib "../lib/store";

mixin (
  accessControlState : AccessControl.AccessControlState,
  products : Map.Map<Types.ProductType, Types.Product>,
  stock : Map.Map<Types.ProductType, [Types.GmailAccount]>,
  orders : Map.Map<Text, Types.Order>,
  qrisConfig : Types.QrisConfig,
) {
  public query func getProducts() : async [Types.Product] {
    products.values().toArray()
  };

  public query func getStockCounts() : async [(Types.ProductType, Nat)] {
    [
      (#fresh, (stock.get(#fresh) ?? []).size()),
      (#bekas, (stock.get(#bekas) ?? []).size()),
    ]
  };

  public shared func createOrder(
    buyerName : Text,
    buyerContact : Text,
    productType : Types.ProductType,
    quantity : Nat,
  ) : async StoreTypes.OrderView {
    let orderNumber = "GM" # Nat.toText(orders.size() + 1);
    let order = StoreLib.createOrder(orders, orderNumber, buyerName, buyerContact, productType, quantity);
    StoreLib.toOrderView(order)
  };

  public query func getOrder(orderNumber : Text) : async ?StoreTypes.OrderView {
    switch (orders.get(orderNumber)) {
      case (?o) ?StoreLib.toOrderView(o);
      case null null;
    };
  };

  public shared ({ caller }) func confirmPayment(orderNumber : Text) : async ?StoreTypes.OrderView {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can confirm payment");
    };
    switch (StoreLib.confirmPayment(orders, stock, orderNumber)) {
      case (?o) ?StoreLib.toOrderView(o);
      case null null;
    };
  };

  public shared ({ caller }) func deliverOrder(orderNumber : Text) : async ?StoreTypes.OrderView {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can deliver orders");
    };
    switch (StoreLib.deliverOrder(orders, stock, orderNumber)) {
      case (?o) ?StoreLib.toOrderView(o);
      case null null;
    };
  };

  public shared ({ caller }) func addGmailAccount(
    productType : Types.ProductType,
    email : Text,
    password : Text,
  ) : async Nat {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can add accounts");
    };
    let id = StoreLib.nextAccountId(stock);
    StoreLib.addGmailAccount(stock, id, productType, email, password);
    id
  };

  public shared ({ caller }) func deleteGmailAccount(
    productType : Types.ProductType,
    accountId : Nat,
  ) : async Bool {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can delete accounts");
    };
    StoreLib.deleteGmailAccount(stock, productType, accountId)
  };

  public query func getQrisConfig() : async Text {
    qrisConfig.code
  };

  public shared ({ caller }) func setQrisConfig(code : Text) : async () {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can set QRIS config");
    };
    qrisConfig.code := code;
  };

  // Store the uploaded QRIS image reference (admin only). The actual file bytes
  // live in object-storage; the backend only keeps the ExternalBlob reference.
  public shared ({ caller }) func setQrisImage(image : Storage.ExternalBlob) : async () {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can set the QRIS image");
    };
    qrisConfig.image := ?image;
  };

  // Retrieve the stored QRIS image reference for display on the checkout page.
  public query func getQrisImage() : async ?Storage.ExternalBlob {
    qrisConfig.image
  };

  public query ({ caller }) func getOrders() : async [StoreTypes.OrderView] {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can view orders");
    };
    orders.values().map(func o = StoreLib.toOrderView(o)).toArray()
  };
};
