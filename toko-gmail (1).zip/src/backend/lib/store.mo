import Map "mo:core/Map";
import Text "mo:core/Text";
import Time "mo:core/Time";
import Types "../types/common";
import StoreTypes "../types/store";

module {
  // Fixed price per product type.
  public func priceOf(productType : Types.ProductType) : Nat {
    switch (productType) {
      case (#fresh) 6000;
      case (#bekas) 3000;
    };
  };

  // Next unique account id across all stock (max existing id + 1).
  public func nextAccountId(stock : Map.Map<Types.ProductType, [Types.GmailAccount]>) : Nat {
    var maxId = 0;
    for ((_, accounts) in stock.entries()) {
      for (a in accounts.values()) {
        if (a.id >= maxId) { maxId := a.id + 1 };
      };
    };
    maxId
  };

  public func addGmailAccount(
    stock : Map.Map<Types.ProductType, [Types.GmailAccount]>,
    id : Nat,
    productType : Types.ProductType,
    email : Text,
    password : Text,
  ) : () {
    let account : Types.GmailAccount = {
      id;
      productType;
      email;
      password;
      var delivered = false;
    };
    let current = stock.get(productType) ?? [];
    stock.add(productType, current.concat([account]));
  };

  public func deleteGmailAccount(
    stock : Map.Map<Types.ProductType, [Types.GmailAccount]>,
    productType : Types.ProductType,
    accountId : Nat,
  ) : Bool {
    let current = stock.get(productType) ?? [];
    let filtered = current.filter(func a = a.id != accountId);
    stock.add(productType, filtered);
    filtered.size() != current.size()
  };

  public func createOrder(
    orders : Map.Map<Text, Types.Order>,
    orderNumber : Text,
    buyerName : Text,
    buyerContact : Text,
    productType : Types.ProductType,
    quantity : Nat,
  ) : Types.Order {
    let order : Types.Order = {
      orderNumber;
      buyerName;
      buyerContact;
      productType;
      quantity;
      totalPrice = priceOf(productType) * quantity;
      var status = #pendingPayment;
      var deliveredAccount = null;
      createdAt = Time.now();
    };
    orders.add(orderNumber, order);
    order
  };

  // Deliver the number of available Gmail accounts matching the order quantity
  // to a #paid order. Each delivered account is marked delivered, removed from
  // stock, and all delivered accounts are stored on the order (one per unit
  // ordered) as 'email|password' entries joined by a newline, so the first
  // entry stays parseable by the frontend CheckoutPage (which splits on '|').
  public func deliverOrder(
    orders : Map.Map<Text, Types.Order>,
    stock : Map.Map<Types.ProductType, [Types.GmailAccount]>,
    orderNumber : Text,
  ) : ?Types.Order {
    switch (orders.get(orderNumber)) {
      case (?order) {
        if (order.status != #paid) { return ?order };
        let accounts = stock.get(order.productType) ?? [];
        let undelivered = accounts.filter(func a = not a.delivered);
        let toDeliver = if (undelivered.size() < order.quantity) {
          undelivered.size();
        } else {
          order.quantity;
        };
        if (toDeliver == 0) { return ?order };
        var delivered : [Text] = [];
        var i = 0;
        while (i < toDeliver) {
          let acc = undelivered[i];
          acc.delivered := true;
          delivered := delivered.concat([acc.email # "|" # acc.password]);
          i += 1;
        };
        order.deliveredAccount := ?delivered.values().join("\n");
        order.status := #delivered;
        let remaining = accounts.filter(func a = not a.delivered);
        stock.add(order.productType, remaining);
        ?order;
      };
      case null null;
    };
  };

  // Confirm payment (status -> #paid) and auto-deliver an account.
  public func confirmPayment(
    orders : Map.Map<Text, Types.Order>,
    stock : Map.Map<Types.ProductType, [Types.GmailAccount]>,
    orderNumber : Text,
  ) : ?Types.Order {
    switch (orders.get(orderNumber)) {
      case (?order) {
        if (order.status != #pendingPayment) { return ?order };
        order.status := #paid;
        ignore deliverOrder(orders, stock, orderNumber);
        ?order;
      };
      case null null;
    };
  };

  public func toOrderView(order : Types.Order) : StoreTypes.OrderView {
    {
      orderNumber = order.orderNumber;
      buyerName = order.buyerName;
      buyerContact = order.buyerContact;
      productType = order.productType;
      quantity = order.quantity;
      totalPrice = order.totalPrice;
      status = order.status;
      deliveredAccount = order.deliveredAccount;
      createdAt = order.createdAt;
    };
  };
};
