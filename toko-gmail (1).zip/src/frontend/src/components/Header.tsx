import { Button } from "@/components/ui/button";
import { Link } from "@tanstack/react-router";
import { Mail, ShieldCheck } from "lucide-react";

export function Header() {
  return (
    <header
      data-ocid="header"
      className="sticky top-0 z-40 border-b bg-card shadow-subtle"
    >
      <div className="mx-auto flex h-16 w-full max-w-6xl items-center justify-between px-4 sm:px-6">
        <Link
          to="/"
          data-ocid="header.brand"
          className="flex items-center gap-2 font-display text-lg font-bold tracking-tight text-foreground"
        >
          <span className="flex size-9 items-center justify-center rounded-xl bg-primary text-primary-foreground">
            <Mail className="size-5" aria-hidden="true" />
          </span>
          Gmailnesia
        </Link>

        <Button
          asChild
          variant="outline"
          size="sm"
          className="rounded-full"
          data-ocid="header.admin_link"
        >
          <Link to="/admin">
            <ShieldCheck className="size-4" aria-hidden="true" />
            Admin
          </Link>
        </Button>
      </div>
    </header>
  );
}
