import { Link } from "@tanstack/react-router";
import { Mail } from "lucide-react";

export function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer
      data-ocid="footer"
      className="border-t bg-muted/40 text-muted-foreground"
    >
      <div className="mx-auto flex w-full max-w-6xl flex-col gap-6 px-4 py-10 sm:px-6 md:flex-row md:items-start md:justify-between">
        <div className="flex flex-col gap-2">
          <div className="flex items-center gap-2 font-display text-base font-bold text-foreground">
            <span className="flex size-7 items-center justify-center rounded-lg bg-primary text-primary-foreground">
              <Mail className="size-4" aria-hidden="true" />
            </span>
            Gmailnesia
          </div>
          <p className="max-w-xs text-sm">
            Akun Gmail siap pakai dengan pengiriman instan dan pembayaran QRIS
            yang aman.
          </p>
        </div>

        <nav aria-label="Tautan toko" className="flex flex-col gap-2 text-sm">
          <span className="font-semibold uppercase tracking-widest text-foreground">
            Toko
          </span>
          <Link
            to="/"
            data-ocid="footer.store_link"
            className="hover:text-foreground"
          >
            Beranda
          </Link>
          <Link
            to="/checkout"
            data-ocid="footer.checkout_link"
            className="hover:text-foreground"
          >
            Checkout
          </Link>
          <Link
            to="/admin"
            data-ocid="footer.admin_link"
            className="hover:text-foreground"
          >
            Admin
          </Link>
        </nav>
      </div>

      <div className="border-t bg-muted/60">
        <div className="mx-auto flex w-full max-w-6xl flex-col items-center justify-between gap-2 px-4 py-4 text-xs sm:flex-row sm:px-6">
          <span>© {year}. Gmailnesia.</span>
          <a
            href={`https://caffeine.ai?utm_source=caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(window.location.hostname)}`}
            target="_blank"
            rel="noreferrer"
            data-ocid="footer.attribution"
            className="hover:text-foreground"
          >
            © {year}. Built with love using caffeine.ai
          </a>
        </div>
      </div>
    </footer>
  );
}
