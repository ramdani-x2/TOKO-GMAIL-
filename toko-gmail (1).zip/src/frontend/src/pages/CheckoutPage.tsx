import { type ExternalBlob, ProductType as ProductTypeEnum } from "@/backend";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import {
  useCreateOrder,
  useGetOrder,
  useProducts,
  useQrisConfig,
  useQrisImage,
} from "@/hooks/useQueries";
import { ORDER_STATUS_LABELS, PRODUCT_LABELS, type ProductType } from "@/types";
import { useSearch } from "@tanstack/react-router";
import {
  CheckCircle2,
  Clock,
  Loader2,
  Mail,
  Minus,
  Plus,
  QrCode,
  ShieldCheck,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";

/** Fallback prices used until the backend product list loads. */
const FALLBACK_PRICES: Record<ProductType, bigint> = {
  [ProductTypeEnum.fresh]: 6000n,
  [ProductTypeEnum.bekas]: 3000n,
};

const PRODUCT_ORDER: ProductType[] = [
  ProductTypeEnum.fresh,
  ProductTypeEnum.bekas,
];

function formatRupiah(value: bigint): string {
  return `Rp${value.toLocaleString("id-ID")}`;
}

export function CheckoutPage() {
  const search = useSearch({ strict: false }) as {
    product?: string;
    qty?: string;
  };

  const initialProduct: ProductType =
    search.product === "bekas" ? ProductTypeEnum.bekas : ProductTypeEnum.fresh;
  const initialQty = Math.max(1, Number(search.qty) || 1);

  const [productType, setProductType] = useState<ProductType>(initialProduct);
  const [quantity, setQuantity] = useState<number>(initialQty);
  const [buyerName, setBuyerName] = useState("");
  const [buyerContact, setBuyerContact] = useState("");
  const [orderNumber, setOrderNumber] = useState<string | null>(null);

  const { data: products } = useProducts();
  const { data: qrisCode, isLoading: qrisLoading } = useQrisConfig();
  const { data: qrisImage, isLoading: qrisImageLoading } = useQrisImage();
  const createOrder = useCreateOrder();

  const price = useMemo(() => {
    const product = products?.find((p) => p.productType === productType);
    return product ? product.price : FALLBACK_PRICES[productType];
  }, [products, productType]);

  const totalPrice = price * BigInt(quantity);

  const orderQuery = useGetOrder(orderNumber);
  const order = orderQuery.data;
  const isDelivered = order?.status === "paid" || order?.status === "delivered";

  // Poll the order status while it is still awaiting payment.
  useEffect(() => {
    if (!orderNumber || isDelivered) return;
    const id = setInterval(() => {
      void orderQuery.refetch();
    }, 4000);
    return () => clearInterval(id);
  }, [orderNumber, isDelivered, orderQuery]);

  const canSubmit =
    buyerName.trim().length > 0 &&
    buyerContact.trim().length > 0 &&
    quantity > 0 &&
    !createOrder.isPending;

  function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!canSubmit) return;
    const name = buyerName.trim();
    const contact = buyerContact.trim();
    setBuyerName("");
    setBuyerContact("");
    createOrder.mutate(
      {
        buyerName: name,
        buyerContact: contact,
        productType,
        quantity: BigInt(quantity),
      },
      {
        onSuccess: (created) => {
          setOrderNumber(created.orderNumber);
        },
        onError: () => {
          setBuyerName((current) => (current === "" ? name : current));
          setBuyerContact((current) => (current === "" ? contact : current));
        },
      },
    );
  }

  function resetCheckout() {
    setOrderNumber(null);
    setQuantity(1);
  }

  return (
    <section
      data-ocid="checkout_page"
      className="mx-auto flex w-full max-w-6xl flex-col gap-8 px-4 py-12 sm:px-6"
    >
      <div className="flex flex-col gap-2">
        <h1 className="font-display text-3xl font-bold tracking-tight md:text-4xl">
          Checkout
        </h1>
        <p className="max-w-xl text-muted-foreground">
          Lengkapi data pembeli, buat pesanan, lalu bayar melalui QRIS untuk
          menerima akun Gmail Anda secara instan.
        </p>
      </div>

      {orderNumber === null ? (
        <CheckoutForm
          productType={productType}
          setProductType={setProductType}
          quantity={quantity}
          setQuantity={setQuantity}
          buyerName={buyerName}
          setBuyerName={setBuyerName}
          buyerContact={buyerContact}
          setBuyerContact={setBuyerContact}
          price={price}
          totalPrice={totalPrice}
          canSubmit={canSubmit}
          isPending={createOrder.isPending}
          error={createOrder.error?.message}
          onSubmit={handleSubmit}
        />
      ) : (
        <PaymentPanel
          orderNumber={orderNumber}
          qrisCode={qrisCode}
          qrisLoading={qrisLoading}
          qrisImage={qrisImage}
          qrisImageLoading={qrisImageLoading}
          order={order}
          isDelivered={isDelivered}
          onReset={resetCheckout}
        />
      )}
    </section>
  );
}

interface CheckoutFormProps {
  productType: ProductType;
  setProductType: (value: ProductType) => void;
  quantity: number;
  setQuantity: (value: number) => void;
  buyerName: string;
  setBuyerName: (value: string) => void;
  buyerContact: string;
  setBuyerContact: (value: string) => void;
  price: bigint;
  totalPrice: bigint;
  canSubmit: boolean;
  isPending: boolean;
  error?: string;
  onSubmit: (event: React.FormEvent<HTMLFormElement>) => void;
}

function CheckoutForm({
  productType,
  setProductType,
  quantity,
  setQuantity,
  buyerName,
  setBuyerName,
  buyerContact,
  setBuyerContact,
  price,
  totalPrice,
  canSubmit,
  isPending,
  error,
  onSubmit,
}: CheckoutFormProps) {
  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_360px]">
      <form
        onSubmit={onSubmit}
        className="flex flex-col gap-6"
        data-ocid="checkout.form"
      >
        <Card>
          <CardHeader>
            <CardTitle>Pilih Produk</CardTitle>
            <CardDescription>
              Pilih jenis akun Gmail dan jumlah yang ingin dibeli.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col gap-4">
            <div className="grid gap-4 sm:grid-cols-2">
              {PRODUCT_ORDER.map((type) => {
                const isFresh = type === "fresh";
                const selected = productType === type;
                return (
                  <button
                    key={type}
                    type="button"
                    data-ocid={`checkout.product.${type}`}
                    onClick={() => setProductType(type)}
                    aria-pressed={selected}
                    className={`flex flex-col gap-3 rounded-2xl border p-5 text-left transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${
                      selected
                        ? isFresh
                          ? "border-primary bg-primary/5 ring-2 ring-primary/30"
                          : "border-accent bg-accent/10 ring-2 ring-accent/40"
                        : "border-border bg-card hover:border-primary/40"
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span
                        className={`flex size-10 items-center justify-center rounded-xl ${
                          isFresh
                            ? "bg-primary text-primary-foreground"
                            : "bg-accent text-accent-foreground"
                        }`}
                      >
                        <Mail className="size-5" aria-hidden="true" />
                      </span>
                      <Badge
                        variant={isFresh ? "default" : "secondary"}
                        className={
                          isFresh ? "" : "bg-accent/20 text-accent-foreground"
                        }
                      >
                        {isFresh ? "Baru" : "Bekas"}
                      </Badge>
                    </div>
                    <div>
                      <p className="font-display text-lg font-bold">
                        {PRODUCT_LABELS[type]}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {formatRupiah(priceFor(type, price, productType))} /
                        akun
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>

            <div className="flex flex-col gap-2">
              <Label htmlFor="checkout.quantity">Jumlah</Label>
              <div className="flex items-center gap-3">
                <Button
                  type="button"
                  variant="outline"
                  size="icon"
                  data-ocid="checkout.quantity.decrease"
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  aria-label="Kurangi jumlah"
                >
                  <Minus className="size-4" aria-hidden="true" />
                </Button>
                <Input
                  id="checkout.quantity"
                  data-ocid="checkout.quantity.input"
                  type="number"
                  min={1}
                  value={quantity}
                  onChange={(e) =>
                    setQuantity(Math.max(1, Number(e.target.value) || 1))
                  }
                  className="w-24 text-center"
                />
                <Button
                  type="button"
                  variant="outline"
                  size="icon"
                  data-ocid="checkout.quantity.increase"
                  onClick={() => setQuantity(quantity + 1)}
                  aria-label="Tambah jumlah"
                >
                  <Plus className="size-4" aria-hidden="true" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Data Pembeli</CardTitle>
            <CardDescription>
              Akun Gmail akan dikirim ke kontak yang Anda isi setelah pembayaran
              dikonfirmasi.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col gap-4">
            <div className="flex flex-col gap-2">
              <Label htmlFor="checkout.buyer_name">Nama Lengkap</Label>
              <Input
                id="checkout.buyer_name"
                data-ocid="checkout.buyer_name.input"
                value={buyerName}
                onChange={(e) => setBuyerName(e.target.value)}
                placeholder="Nama Anda"
                autoComplete="name"
              />
            </div>
            <div className="flex flex-col gap-2">
              <Label htmlFor="checkout.buyer_contact">
                Kontak (WhatsApp / Email)
              </Label>
              <Input
                id="checkout.buyer_contact"
                data-ocid="checkout.buyer_contact.input"
                value={buyerContact}
                onChange={(e) => setBuyerContact(e.target.value)}
                placeholder="contoh: 0812xxxx atau email@contoh.com"
                autoComplete="email"
              />
            </div>
          </CardContent>
        </Card>

        {error ? (
          <p
            data-ocid="checkout.error_state"
            className="rounded-lg border border-destructive/30 bg-destructive/10 px-4 py-3 text-sm text-destructive"
          >
            Gagal membuat pesanan. Silakan coba lagi.
          </p>
        ) : null}

        <Button
          type="submit"
          size="lg"
          data-ocid="checkout.submit_button"
          disabled={!canSubmit}
          className="w-full"
        >
          {isPending ? (
            <>
              <Loader2 className="size-4 animate-spin" aria-hidden="true" />
              Membuat Pesanan...
            </>
          ) : (
            "Buat Pesanan"
          )}
        </Button>
      </form>

      <aside className="lg:sticky lg:top-24 lg:self-start">
        <Card className="lg:max-w-[360px]">
          <CardHeader>
            <CardTitle>Ringkasan Pesanan</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Produk</span>
              <span className="font-medium">{PRODUCT_LABELS[productType]}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Harga Satuan</span>
              <span className="font-medium">{formatRupiah(price)}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Jumlah</span>
              <span className="font-medium">{quantity} akun</span>
            </div>
            <div className="flex items-center justify-between border-t pt-4">
              <span className="font-semibold">Total</span>
              <span className="font-display text-xl font-bold text-primary">
                {formatRupiah(totalPrice)}
              </span>
            </div>
            <p className="text-center text-xs text-muted-foreground">
              Dengan membuat pesanan, Anda menyetujui pengiriman akun setelah
              pembayaran dikonfirmasi.
            </p>
          </CardContent>
        </Card>
      </aside>
    </div>
  );
}

function priceFor(
  type: ProductType,
  currentPrice: bigint,
  currentType: ProductType,
): bigint {
  if (type === currentType) return currentPrice;
  return FALLBACK_PRICES[type];
}

interface PaymentPanelProps {
  orderNumber: string | null;
  qrisCode: string | undefined;
  qrisLoading: boolean;
  qrisImage: ExternalBlob | null | undefined;
  qrisImageLoading: boolean;
  order: ReturnType<typeof useGetOrder>["data"];
  isDelivered: boolean;
  onReset: () => void;
}

function PaymentPanel({
  orderNumber,
  qrisCode,
  qrisLoading,
  qrisImage,
  qrisImageLoading,
  order,
  isDelivered,
  onReset,
}: PaymentPanelProps) {
  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <span className="flex size-10 items-center justify-center rounded-xl bg-primary text-primary-foreground">
              <QrCode className="size-5" aria-hidden="true" />
            </span>
            <div>
              <CardTitle>Bayar Melalui QRIS</CardTitle>
              <CardDescription>
                Scan kode QRIS di bawah ini sesuai nominal total.
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="flex flex-col items-center gap-4">
          <div className="flex w-full flex-col gap-2 rounded-xl border bg-muted/40 p-4 text-sm">
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Nomor Pesanan</span>
              <span
                data-ocid="checkout.order_number"
                className="font-mono font-semibold"
              >
                {orderNumber}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Nominal</span>
              <span
                data-ocid="checkout.total"
                className="font-display text-lg font-bold text-primary"
              >
                {order ? formatRupiah(order.totalPrice) : "—"}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Status</span>
              <Badge variant="secondary">
                {order ? ORDER_STATUS_LABELS[order.status] : "Menunggu"}
              </Badge>
            </div>
          </div>

          {qrisLoading || qrisImageLoading ? (
            <Skeleton className="h-56 w-56 rounded-2xl" />
          ) : qrisImage ? (
            <img
              src={qrisImage.getDirectURL()}
              alt="Kode QRIS merchant untuk pembayaran"
              data-ocid="checkout.qris_image"
              className="size-56 rounded-2xl border bg-white object-contain p-2"
            />
          ) : qrisCode ? (
            qrisCode.startsWith("data:image") ? (
              <img
                src={qrisCode}
                alt="Kode QRIS merchant untuk pembayaran"
                data-ocid="checkout.qris_image"
                className="size-56 rounded-2xl border bg-white object-contain p-2"
              />
            ) : (
              <div
                data-ocid="checkout.qris_code"
                className="flex w-full flex-col items-center gap-2 rounded-2xl border bg-muted/40 p-6 text-center"
              >
                <QrCode className="size-10 text-primary" aria-hidden="true" />
                <p className="font-mono text-sm break-all">{qrisCode}</p>
              </div>
            )
          ) : (
            <p
              data-ocid="checkout.qris_empty_state"
              className="text-sm text-muted-foreground"
            >
              Kode QRIS merchant belum dikonfigurasi oleh admin.
            </p>
          )}

          <div className="flex items-start gap-2 rounded-xl bg-muted/40 p-3 text-xs text-muted-foreground">
            <Clock className="mt-0.5 size-4 shrink-0" aria-hidden="true" />
            <p>
              Setelah pembayaran dikonfirmasi, akun Gmail Anda akan dikirim
              otomatis dan tampil di layar ini. Halaman ini memeriksa status
              pesanan secara berkala.
            </p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Status Pengiriman</CardTitle>
          <CardDescription>Pantau status pesanan Anda di sini.</CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col gap-4">
          {!order ? (
            <div className="flex flex-col gap-3">
              <Skeleton className="h-5 w-2/3" />
              <Skeleton className="h-5 w-1/2" />
              <Skeleton className="h-24 w-full" />
            </div>
          ) : isDelivered ? (
            <div
              data-ocid="checkout.success_state"
              className="flex flex-col gap-4"
            >
              <div className="flex items-center gap-3 rounded-xl border border-success/30 bg-success/10 p-4">
                <CheckCircle2
                  className="size-6 shrink-0 text-success"
                  aria-hidden="true"
                />
                <div>
                  <p className="font-semibold text-foreground">
                    Pembayaran Dikonfirmasi
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Akun Gmail Anda telah dikirim. Simpan kredensial berikut
                    dengan aman.
                  </p>
                </div>
              </div>

              <div className="flex flex-col gap-3 rounded-2xl border bg-muted/40 p-5">
                <div className="flex items-center gap-2">
                  <span className="flex size-9 items-center justify-center rounded-lg bg-primary text-primary-foreground">
                    <Mail className="size-4" aria-hidden="true" />
                  </span>
                  <span className="font-semibold">
                    {PRODUCT_LABELS[order.productType]}
                  </span>
                </div>
                <div className="flex flex-col gap-1">
                  <Label>Email</Label>
                  <div className="rounded-lg border bg-card px-3 py-2 font-mono text-sm break-all">
                    {order.deliveredAccount?.split("|")[0] ?? "—"}
                  </div>
                </div>
                <div className="flex flex-col gap-1">
                  <Label>Password</Label>
                  <div className="rounded-lg border bg-card px-3 py-2 font-mono text-sm break-all">
                    {order.deliveredAccount?.split("|")[1] ?? "—"}
                  </div>
                </div>
              </div>

              <div className="flex items-start gap-2 rounded-xl bg-muted/40 p-3 text-xs text-muted-foreground">
                <ShieldCheck
                  className="mt-0.5 size-4 shrink-0"
                  aria-hidden="true"
                />
                <p>
                  Jangan bagikan kredensial akun ini kepada siapa pun. Ganti
                  kata sandi segera setelah login untuk keamanan.
                </p>
              </div>

              <Button
                variant="outline"
                data-ocid="checkout.new_order_button"
                onClick={onReset}
              >
                Buat Pesanan Baru
              </Button>
            </div>
          ) : (
            <div
              data-ocid="checkout.loading_state"
              className="flex flex-col items-center gap-3 py-8 text-center"
            >
              <Loader2
                className="size-8 animate-spin text-primary"
                aria-hidden="true"
              />
              <p className="font-medium">Menunggu Konfirmasi Pembayaran</p>
              <p className="max-w-sm text-sm text-muted-foreground">
                Silakan selesaikan pembayaran QRIS sebesar{" "}
                <span className="font-semibold text-foreground">
                  {formatRupiah(order.totalPrice)}
                </span>{" "}
                untuk pesanan{" "}
                <span className="font-mono font-semibold">
                  {order.orderNumber}
                </span>
                . Akun akan dikirim otomatis setelah pembayaran dikonfirmasi.
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
