import { ProductType } from "@/backend";
import { Button } from "@/components/ui/button";
import { useStockCounts } from "@/hooks/useQueries";
import { PRODUCT_LABELS } from "@/types";
import { useNavigate } from "@tanstack/react-router";
import {
  BadgeCheck,
  Minus,
  Plus,
  ShieldCheck,
  Sparkles,
  Zap,
} from "lucide-react";
import { useState } from "react";

interface ProductCardConfig {
  type: ProductType;
  price: number;
  theme: "fresh" | "bekas";
  tagline: string;
  description: string;
}

const PRODUCTS: ProductCardConfig[] = [
  {
    type: ProductType.fresh,
    price: 6000,
    theme: "fresh",
    tagline: "Baru & Siap Pakai",
    description:
      "Akun Gmail baru yang belum pernah dipakai, langsung aktif untuk kebutuhan Anda.",
  },
  {
    type: ProductType.bekas,
    price: 3000,
    theme: "bekas",
    tagline: "Hemat & Terjangkau",
    description:
      "Akun Gmail bekas dengan harga terjangkau, tetap berfungsi penuh untuk berbagai keperluan.",
  },
];

const TRUST_ITEMS = [
  "Pengiriman Instan",
  "Pembayaran QRIS",
  "Garansi Akun",
  "Stok Selalu Tersedia",
];

function formatPrice(value: number): string {
  return `Rp${value.toLocaleString("id-ID")}`;
}

export function StorefrontPage() {
  const navigate = useNavigate();
  const { data: stockCounts } = useStockCounts();
  const [quantities, setQuantities] = useState<Record<ProductType, number>>({
    [ProductType.fresh]: 1,
    [ProductType.bekas]: 1,
  });

  const stockFor = (type: ProductType): bigint | undefined => {
    const entry = stockCounts?.find(([productType]) => productType === type);
    return entry?.[1];
  };

  const scrollToProducts = () => {
    document
      .getElementById("products")
      ?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const changeQuantity = (type: ProductType, delta: number) => {
    setQuantities((current) => ({
      ...current,
      [type]: Math.max(1, current[type] + delta),
    }));
  };

  const buyNow = (type: ProductType) => {
    navigate({
      to: "/checkout",
      search: { product: type, qty: quantities[type] },
    });
  };

  return (
    <div data-ocid="storefront_page" className="bg-background">
      {/* Hero */}
      <section data-ocid="storefront.hero" className="bg-gradient-subtle">
        <div className="mx-auto flex w-full max-w-6xl flex-col items-center px-4 pb-16 pt-20 text-center sm:px-6 md:pb-24 md:pt-28">
          <span className="mb-6 inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/10 px-4 py-1.5 text-sm font-medium text-primary">
            <Sparkles className="size-4" aria-hidden="true" />
            Pengiriman Instan &amp; Terpercaya
          </span>
          <h1 className="max-w-3xl font-display text-4xl font-bold tracking-tight text-foreground sm:text-5xl md:text-6xl">
            Akun Gmail <span className="text-gradient-primary">Siap Pakai</span>
          </h1>
          <p className="mt-6 max-w-xl text-lg text-muted-foreground">
            Dapatkan akun Gmail berkualitas dengan harga terbaik. Pembayaran
            mudah lewat QRIS dan akun dikirim otomatis setelah pembayaran
            dikonfirmasi.
          </p>
          <Button
            size="lg"
            className="mt-10 rounded-full px-8"
            data-ocid="storefront.hero_cta"
            onClick={scrollToProducts}
          >
            Pesan Sekarang
          </Button>
          <img
            src="/assets/generated/gmail-hero.dim_1200x600.png"
            alt="Ilustrasi akun Gmail siap pakai dengan pembayaran QRIS dan pengiriman instan"
            data-ocid="storefront.hero_image"
            className="mt-14 w-full max-w-3xl rounded-3xl border border-border shadow-subtle"
            loading="eager"
          />
        </div>
      </section>

      {/* Products */}
      <section
        id="products"
        data-ocid="storefront.products"
        className="mx-auto w-full max-w-6xl scroll-mt-24 px-4 py-16 sm:px-6 md:py-24"
      >
        <div className="mb-12 text-center">
          <h2 className="font-display text-3xl font-bold tracking-tight text-foreground md:text-4xl">
            Pilih Paket Anda
          </h2>
          <p className="mt-3 text-muted-foreground">
            Pilih jumlah dan lanjutkan ke pembayaran QRIS.
          </p>
        </div>

        <div className="grid gap-8 md:grid-cols-2">
          {PRODUCTS.map((product) => {
            const isFresh = product.theme === "fresh";
            const stock = stockFor(product.type);
            const quantity = quantities[product.type];
            const total = product.price * quantity;

            return (
              <article
                key={product.type}
                data-ocid={`storefront.product_card.${product.type}`}
                className={`flex flex-col rounded-3xl border bg-card p-8 shadow-subtle transition-smooth hover:-translate-y-1 ${
                  isFresh ? "border-primary/20" : "border-accent/30"
                }`}
              >
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <h3 className="font-display text-2xl font-bold tracking-tight text-foreground">
                      {PRODUCT_LABELS[product.type]}
                    </h3>
                    <p className="mt-1 text-sm font-medium text-muted-foreground">
                      {product.tagline}
                    </p>
                  </div>
                  <span
                    className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold ${
                      isFresh
                        ? "bg-primary/10 text-primary"
                        : "bg-accent/15 text-accent-foreground"
                    }`}
                  >
                    <ShieldCheck className="size-3.5" aria-hidden="true" />
                    {stock !== undefined ? `${stock} tersedia` : "Tersedia"}
                  </span>
                </div>

                <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
                  {product.description}
                </p>

                <div className="mt-6 flex items-baseline gap-2">
                  <span
                    className={`font-display text-4xl font-bold tracking-tight ${
                      isFresh ? "text-primary" : "text-accent-foreground"
                    }`}
                  >
                    {formatPrice(product.price)}
                  </span>
                  <span className="text-sm text-muted-foreground">/ akun</span>
                </div>

                {/* Quantity selector */}
                <div className="mt-6">
                  <span className="text-sm font-medium text-foreground">
                    Jumlah
                  </span>
                  <div className="mt-2 flex items-center gap-3">
                    <Button
                      type="button"
                      variant="outline"
                      size="icon"
                      className="size-10 rounded-full"
                      aria-label={`Kurangi jumlah ${PRODUCT_LABELS[product.type]}`}
                      data-ocid={`storefront.quantity_minus.${product.type}`}
                      onClick={() => changeQuantity(product.type, -1)}
                    >
                      <Minus className="size-4" aria-hidden="true" />
                    </Button>
                    <span
                      className="w-12 text-center font-display text-xl font-bold text-foreground"
                      data-ocid={`storefront.quantity_value.${product.type}`}
                      aria-live="polite"
                    >
                      {quantity}
                    </span>
                    <Button
                      type="button"
                      variant="outline"
                      size="icon"
                      className="size-10 rounded-full"
                      aria-label={`Tambah jumlah ${PRODUCT_LABELS[product.type]}`}
                      data-ocid={`storefront.quantity_plus.${product.type}`}
                      onClick={() => changeQuantity(product.type, 1)}
                    >
                      <Plus className="size-4" aria-hidden="true" />
                    </Button>
                  </div>
                </div>

                {/* Trust badges */}
                <div className="mt-6 flex flex-wrap gap-2">
                  <span className="inline-flex items-center gap-1.5 rounded-full bg-muted px-3 py-1 text-xs font-medium text-muted-foreground">
                    <Zap className="size-3.5" aria-hidden="true" />
                    Pengiriman Instan
                  </span>
                  <span className="inline-flex items-center gap-1.5 rounded-full bg-muted px-3 py-1 text-xs font-medium text-muted-foreground">
                    <BadgeCheck className="size-3.5" aria-hidden="true" />
                    Pembayaran QRIS
                  </span>
                </div>

                <div className="mt-8 flex items-center justify-between border-t pt-6">
                  <div>
                    <span className="block text-xs text-muted-foreground">
                      Total
                    </span>
                    <span className="font-display text-xl font-bold text-foreground">
                      {formatPrice(total)}
                    </span>
                  </div>
                  <Button
                    className={`rounded-full px-6 ${
                      isFresh
                        ? ""
                        : "bg-accent text-accent-foreground hover:bg-accent/90"
                    }`}
                    data-ocid={`storefront.buy_button.${product.type}`}
                    onClick={() => buyNow(product.type)}
                  >
                    Beli Sekarang
                  </Button>
                </div>
              </article>
            );
          })}
        </div>
      </section>

      {/* Trust strip */}
      <section data-ocid="storefront.trust_strip" className="border-y bg-card">
        <div className="mx-auto grid w-full max-w-6xl grid-cols-2 gap-6 px-4 py-10 sm:px-6 md:grid-cols-4">
          {TRUST_ITEMS.map((item) => (
            <div
              key={item}
              className="flex items-center justify-center gap-2 text-center"
            >
              <BadgeCheck
                className="size-5 shrink-0 text-primary"
                aria-hidden="true"
              />
              <span className="text-sm font-medium text-foreground">
                {item}
              </span>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
