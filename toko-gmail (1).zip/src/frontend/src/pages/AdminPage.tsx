import { type OrderStatus, ProductType } from "@/backend";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  timestampToDate,
  useAddGmailAccount,
  useConfirmPayment,
  useDeleteGmailAccount,
  useDeliverOrder,
  useIsCallerAdmin,
  useOrders,
  useQrisConfig,
  useQrisImage,
  useSetQrisConfig,
  useSetQrisImage,
  useStockCounts,
} from "@/hooks/useQueries";
import { ORDER_STATUS_LABELS, PRODUCT_LABELS } from "@/types";
import { useInternetIdentity } from "@caffeineai/core-infrastructure";
import { ExternalBlob } from "@caffeineai/object-storage";
import {
  CheckCircle2,
  Loader2,
  Lock,
  Package,
  Plus,
  QrCode,
  ShieldCheck,
  Trash2,
  Truck,
  Wallet,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

const PRODUCT_TYPES: ProductType[] = [ProductType.fresh, ProductType.bekas];

function formatPrice(value: bigint): string {
  return `Rp${Number(value).toLocaleString("id-ID")}`;
}

function formatDate(timestamp: bigint): string {
  const date = timestampToDate(timestamp);
  if (!date) return "-";
  return new Intl.DateTimeFormat("id-ID", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }).format(date);
}

function statusVariant(
  status: OrderStatus,
): "default" | "secondary" | "outline" {
  if (status === "delivered") return "default";
  if (status === "paid") return "secondary";
  return "outline";
}

function LoginPrompt() {
  const { login, isInitializing, isLoggingIn } = useInternetIdentity();
  const disabled = isInitializing || isLoggingIn;

  return (
    <section
      data-ocid="admin_login_prompt"
      className="mx-auto flex w-full max-w-md flex-col items-center gap-6 px-4 py-24 text-center sm:px-6"
    >
      <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10 text-primary">
        <Lock className="h-8 w-8" />
      </div>
      <div className="space-y-2">
        <h1 className="font-display text-3xl font-bold tracking-tight">
          Halaman Admin
        </h1>
        <p className="text-muted-foreground">
          Masuk untuk mengelola stok akun Gmail, melihat pesanan, dan mengatur
          kode QRIS.
        </p>
      </div>
      <Button
        data-ocid="admin_login_button"
        size="lg"
        onClick={() => login()}
        disabled={disabled}
      >
        {disabled ? (
          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
        ) : (
          <ShieldCheck className="mr-2 h-4 w-4" />
        )}
        {isInitializing
          ? "Memuat..."
          : isLoggingIn
            ? "Membuka jendela masuk..."
            : "Masuk dengan Internet Identity"}
      </Button>
      <p className="text-sm text-muted-foreground">
        Pengguna pertama yang masuk otomatis menjadi admin.
      </p>
    </section>
  );
}

function StockSection() {
  const { data: stockCounts, isLoading: stockLoading } = useStockCounts();
  const addAccount = useAddGmailAccount();
  const deleteAccount = useDeleteGmailAccount();

  const [productType, setProductType] = useState<ProductType>(
    ProductType.fresh,
  );
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [deleteId, setDeleteId] = useState("");

  const handleDelete = () => {
    const id = BigInt(deleteId.trim() || "0");
    if (id <= 0n) {
      toast.error("Masukkan ID akun yang valid");
      return;
    }
    deleteAccount.mutate(
      { productType, accountId: id },
      {
        onSuccess: (ok) => {
          if (ok) {
            toast.success("Akun Gmail dihapus");
            setDeleteId("");
          } else {
            toast.error("Akun tidak ditemukan");
          }
        },
        onError: () => toast.error("Gagal menghapus akun"),
      },
    );
  };

  const countFor = (type: ProductType): bigint => {
    const entry = stockCounts?.find(([t]) => t === type);
    return entry ? entry[1] : 0n;
  };

  const handleAdd = () => {
    const trimmedEmail = email.trim();
    const trimmedPassword = password.trim();
    if (!trimmedEmail || !trimmedPassword) {
      toast.error("Lengkapi email dan password akun");
      return;
    }
    setEmail("");
    setPassword("");
    addAccount.mutate(
      {
        productType,
        email: trimmedEmail,
        password: trimmedPassword,
      },
      {
        onSuccess: (id) =>
          toast.success(
            `Akun Gmail berhasil ditambahkan (ID ${id}). Gunakan ID ini untuk menghapus akun.`,
          ),
        onError: (err) => {
          toast.error("Gagal menambahkan akun");
          setEmail((current) => (current === "" ? trimmedEmail : current));
          setPassword((current) =>
            current === "" ? trimmedPassword : current,
          );
          console.error(err);
        },
      },
    );
  };

  return (
    <Card data-ocid="admin_stock_section">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Package className="h-5 w-5 text-primary" />
          Stok Akun
        </CardTitle>
        <CardDescription>
          Tambah atau hapus akun Gmail untuk stok Fresh dan Bekas.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid gap-4 sm:grid-cols-2">
          {PRODUCT_TYPES.map((type) => (
            <div
              key={type}
              data-ocid={`admin_stock_card.${type}`}
              className="flex items-center justify-between rounded-xl border border-border bg-muted/40 p-4"
            >
              <div>
                <p className="font-display font-semibold">
                  {PRODUCT_LABELS[type]}
                </p>
                <p className="text-sm text-muted-foreground">
                  {stockLoading
                    ? "Memuat..."
                    : `${Number(countFor(type)).toLocaleString("id-ID")} akun tersedia`}
                </p>
              </div>
              <Badge
                variant={type === "fresh" ? "default" : "secondary"}
                className="text-base"
              >
                {stockLoading
                  ? "…"
                  : Number(countFor(type)).toLocaleString("id-ID")}
              </Badge>
            </div>
          ))}
        </div>

        <div className="space-y-4 rounded-xl border border-border p-4">
          <p className="font-medium">Tambah Akun Gmail</p>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="stock-product-type">Jenis Akun</Label>
              <Select
                value={productType}
                onValueChange={(v) => setProductType(v as ProductType)}
              >
                <SelectTrigger
                  id="stock-product-type"
                  data-ocid="admin_stock_type_select"
                >
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {PRODUCT_TYPES.map((type) => (
                    <SelectItem key={type} value={type}>
                      {PRODUCT_LABELS[type]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="stock-email">Email</Label>
              <Input
                id="stock-email"
                data-ocid="admin_stock_email_input"
                type="email"
                placeholder="akun@gmail.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <div className="space-y-2 sm:col-span-2">
              <Label htmlFor="stock-password">Password</Label>
              <Input
                id="stock-password"
                data-ocid="admin_stock_password_input"
                type="text"
                placeholder="Password akun"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
          </div>
          <Button
            data-ocid="admin_stock_add_button"
            onClick={handleAdd}
            disabled={addAccount.isPending || !email.trim() || !password.trim()}
          >
            {addAccount.isPending ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <Plus className="mr-2 h-4 w-4" />
            )}
            {addAccount.isPending ? "Menyimpan..." : "Tambah Akun"}
          </Button>
        </div>

        <div className="space-y-2">
          <p className="font-medium">Hapus Akun dari Stok</p>
          <p className="text-sm text-muted-foreground">
            Pilih jenis akun lalu masukkan ID akun untuk menghapusnya dari stok.
          </p>
          <div className="flex flex-col gap-3 sm:flex-row sm:items-end">
            <div className="flex-1 space-y-2">
              <Label htmlFor="delete-product-type">Jenis Akun</Label>
              <Select
                value={productType}
                onValueChange={(v) => setProductType(v as ProductType)}
              >
                <SelectTrigger
                  id="delete-product-type"
                  data-ocid="admin_stock_delete_type_select"
                >
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {PRODUCT_TYPES.map((type) => (
                    <SelectItem key={type} value={type}>
                      {PRODUCT_LABELS[type]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex-1 space-y-2">
              <Label htmlFor="delete-account-id">ID Akun</Label>
              <Input
                id="delete-account-id"
                data-ocid="admin_stock_delete_id_input"
                type="number"
                placeholder="Contoh: 1"
                value={deleteId}
                onChange={(e) => setDeleteId(e.target.value)}
              />
            </div>
            <Button
              data-ocid="admin_stock_delete_button"
              variant="destructive"
              onClick={handleDelete}
              disabled={deleteAccount.isPending || !deleteId.trim()}
            >
              {deleteAccount.isPending ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Trash2 className="mr-2 h-4 w-4" />
              )}
              {deleteAccount.isPending ? "Menghapus..." : "Hapus Akun"}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function OrdersSection() {
  const { data: orders, isLoading: ordersLoading } = useOrders();
  const confirmPayment = useConfirmPayment();
  const deliverOrder = useDeliverOrder();

  const handleConfirm = (orderNumber: string) => {
    confirmPayment.mutate(orderNumber, {
      onSuccess: (order) => {
        if (order) toast.success("Pembayaran dikonfirmasi");
        else toast.error("Pesanan tidak ditemukan");
      },
      onError: () => toast.error("Gagal mengonfirmasi pembayaran"),
    });
  };

  const handleDeliver = (orderNumber: string) => {
    deliverOrder.mutate(orderNumber, {
      onSuccess: (order) => {
        if (order) toast.success("Pesanan ditandai terkirim");
        else toast.error("Pesanan tidak ditemukan");
      },
      onError: () => toast.error("Gagal menandai pesanan terkirim"),
    });
  };

  return (
    <Card data-ocid="admin_orders_section">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Wallet className="h-5 w-5 text-primary" />
          Pesanan
        </CardTitle>
        <CardDescription>
          Daftar semua pesanan beserta status pembayaran dan pengiriman.
        </CardDescription>
      </CardHeader>
      <CardContent>
        {ordersLoading ? (
          <div
            data-ocid="admin_orders_loading"
            className="flex items-center justify-center py-12 text-muted-foreground"
          >
            <Loader2 className="mr-2 h-5 w-5 animate-spin" />
            Memuat pesanan...
          </div>
        ) : !orders || orders.length === 0 ? (
          <div
            data-ocid="admin_orders_empty"
            className="flex flex-col items-center gap-2 py-12 text-center"
          >
            <Wallet className="h-10 w-10 text-muted-foreground/50" />
            <p className="font-medium">Belum ada pesanan</p>
            <p className="text-sm text-muted-foreground">
              Pesanan dari pembeli akan muncul di sini.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>No. Pesanan</TableHead>
                  <TableHead>Pembeli</TableHead>
                  <TableHead>Produk</TableHead>
                  <TableHead className="text-right">Jumlah</TableHead>
                  <TableHead className="text-right">Total</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Dibuat</TableHead>
                  <TableHead className="text-right">Aksi</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {orders.map((order, index) => (
                  <TableRow key={order.orderNumber}>
                    <TableCell className="font-mono text-xs">
                      {order.orderNumber}
                    </TableCell>
                    <TableCell>
                      <div className="min-w-0">
                        <p className="truncate font-medium">
                          {order.buyerName}
                        </p>
                        <p className="truncate text-xs text-muted-foreground">
                          {order.buyerContact}
                        </p>
                      </div>
                    </TableCell>
                    <TableCell>{PRODUCT_LABELS[order.productType]}</TableCell>
                    <TableCell className="text-right">
                      {Number(order.quantity).toLocaleString("id-ID")}
                    </TableCell>
                    <TableCell className="text-right font-medium">
                      {formatPrice(order.totalPrice)}
                    </TableCell>
                    <TableCell>
                      <Badge variant={statusVariant(order.status)}>
                        {ORDER_STATUS_LABELS[order.status]}
                      </Badge>
                    </TableCell>
                    <TableCell className="whitespace-nowrap text-xs text-muted-foreground">
                      {formatDate(order.createdAt)}
                    </TableCell>
                    <TableCell>
                      <div className="flex justify-end gap-2">
                        {order.status === "pendingPayment" && (
                          <Button
                            data-ocid={`admin_order_confirm.${index}`}
                            size="sm"
                            variant="outline"
                            onClick={() => handleConfirm(order.orderNumber)}
                            disabled={confirmPayment.isPending}
                          >
                            <CheckCircle2 className="mr-1.5 h-4 w-4" />
                            Konfirmasi
                          </Button>
                        )}
                        {order.status === "paid" && (
                          <Button
                            data-ocid={`admin_order_deliver.${index}`}
                            size="sm"
                            onClick={() => handleDeliver(order.orderNumber)}
                            disabled={deliverOrder.isPending}
                          >
                            <Truck className="mr-1.5 h-4 w-4" />
                            Kirim
                          </Button>
                        )}
                        {order.status === "delivered" && (
                          <span className="text-xs text-muted-foreground">
                            {order.deliveredAccount
                              ? `Terkirim ke ${order.deliveredAccount}`
                              : "Selesai"}
                          </span>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function QrisSection() {
  const { data: qrisConfig, isLoading: qrisLoading } = useQrisConfig();
  const { data: qrisImage, isLoading: qrisImageLoading } = useQrisImage();
  const setQrisConfig = useSetQrisConfig();
  const setQrisImage = useSetQrisImage();
  const [code, setCode] = useState("");
  const [fileName, setFileName] = useState("");

  const handleSave = () => {
    const trimmed = code.trim();
    if (!trimmed) {
      toast.error("Masukkan kode QRIS");
      return;
    }
    setCode("");
    setQrisConfig.mutate(trimmed, {
      onSuccess: () => toast.success("Kode QRIS diperbarui"),
      onError: () => {
        toast.error("Gagal memperbarui kode QRIS");
        setCode((current) => (current === "" ? trimmed : current));
      },
    });
  };

  const handleUpload = async (file: File | undefined) => {
    if (!file) return;
    const bytes = new Uint8Array(await file.arrayBuffer());
    const blob = ExternalBlob.fromBytes(bytes, file.type, file.name);
    setFileName(file.name);
    setQrisImage.mutate(blob, {
      onSuccess: () => toast.success("Gambar QRIS berhasil diunggah"),
      onError: () => {
        toast.error("Gagal mengunggah gambar QRIS");
        setFileName("");
      },
    });
  };

  return (
    <Card data-ocid="admin_qris_section">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <QrCode className="h-5 w-5 text-primary" />
          Kode QRIS
        </CardTitle>
        <CardDescription>
          Atur kode QRIS yang ditampilkan kepada pembeli saat checkout.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="rounded-xl border border-border bg-muted/40 p-4">
          <p className="text-sm font-medium">Kode QRIS Saat Ini</p>
          <p className="mt-1 break-all font-mono text-sm text-muted-foreground">
            {qrisLoading
              ? "Memuat..."
              : qrisConfig?.trim()
                ? qrisConfig
                : "Belum diatur"}
          </p>
        </div>
        <div className="space-y-2">
          <Label htmlFor="qris-code">Kode QRIS Baru</Label>
          <Input
            id="qris-code"
            data-ocid="admin_qris_input"
            placeholder="Tempel kode QRIS di sini"
            value={code}
            onChange={(e) => setCode(e.target.value)}
          />
        </div>
        <Button
          data-ocid="admin_qris_save_button"
          onClick={handleSave}
          disabled={setQrisConfig.isPending || !code.trim()}
        >
          {setQrisConfig.isPending ? (
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          ) : (
            <CheckCircle2 className="mr-2 h-4 w-4" />
          )}
          {setQrisConfig.isPending ? "Menyimpan..." : "Simpan Kode QRIS"}
        </Button>

        <div className="space-y-3 rounded-xl border border-border p-4">
          <div>
            <p className="text-sm font-medium">Gambar QRIS</p>
            <p className="text-sm text-muted-foreground">
              Unggah gambar kode QRIS (PNG/JPG) untuk ditampilkan pada halaman
              checkout.
            </p>
          </div>
          {qrisImageLoading ? (
            <p className="text-sm text-muted-foreground">Memuat gambar...</p>
          ) : qrisImage ? (
            <div className="flex items-center gap-4">
              <img
                src={qrisImage.getDirectURL()}
                alt="Kode QRIS merchant untuk pembayaran"
                data-ocid="admin_qris_image_preview"
                className="size-28 rounded-xl border bg-white object-contain p-1"
              />
              <p className="text-sm text-muted-foreground">
                Gambar QRIS saat ini terpasang.
              </p>
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">Belum diatur</p>
          )}
          <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
            <Input
              id="qris-image"
              data-ocid="admin_qris_image_input"
              type="file"
              accept="image/png,image/jpeg"
              onChange={(e) => void handleUpload(e.target.files?.[0])}
              className="max-w-sm"
            />
            {setQrisImage.isPending && (
              <span className="flex items-center gap-2 text-sm text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin" />
                Mengunggah...
              </span>
            )}
          </div>
          {fileName && !setQrisImage.isPending && (
            <p className="text-xs text-muted-foreground">
              File terpilih: {fileName}
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

export function AdminPage() {
  const { isAuthenticated } = useInternetIdentity();
  const { data: isAdmin, isLoading: adminLoading } = useIsCallerAdmin();

  if (!isAuthenticated) {
    return <LoginPrompt />;
  }

  if (adminLoading) {
    return (
      <section
        data-ocid="admin_loading"
        className="mx-auto flex w-full max-w-6xl flex-col items-center gap-4 px-4 py-24 text-center sm:px-6"
      >
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <p className="text-muted-foreground">Memeriksa akses admin...</p>
      </section>
    );
  }

  if (!isAdmin) {
    return (
      <section
        data-ocid="admin_denied"
        className="mx-auto flex w-full max-w-md flex-col items-center gap-6 px-4 py-24 text-center sm:px-6"
      >
        <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-destructive/10 text-destructive">
          <Lock className="h-8 w-8" />
        </div>
        <div className="space-y-2">
          <h1 className="font-display text-3xl font-bold tracking-tight">
            Akses Ditolak
          </h1>
          <p className="text-muted-foreground">
            Anda tidak memiliki izin admin untuk mengakses halaman ini.
          </p>
        </div>
      </section>
    );
  }

  return (
    <section
      data-ocid="admin_page"
      className="mx-auto flex w-full max-w-6xl flex-col gap-8 px-4 py-10 sm:px-6"
    >
      <div className="space-y-2">
        <h1 className="font-display text-3xl font-bold tracking-tight md:text-4xl">
          Dashboard Admin
        </h1>
        <p className="text-muted-foreground">
          Kelola stok akun Gmail, pantau pesanan, dan atur kode QRIS.
        </p>
      </div>

      <StockSection />
      <OrdersSection />
      <QrisSection />
    </section>
  );
}
