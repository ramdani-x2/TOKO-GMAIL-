import type { OrderStatus, OrderView, ProductType } from "@/backend";

export type { OrderStatus, OrderView, ProductType };

/** A single order as returned by the backend. */
export type Order = OrderView;

/** A Gmail account held in stock, keyed by its backend account id. */
export interface GmailAccount {
  id: bigint;
  productType: ProductType;
  email: string;
  password: string;
}

/** The merchant QRIS configuration (the QR code string shown at checkout). */
export interface QrisConfig {
  code: string;
}

/** Human-readable labels for the two product tiers. */
export const PRODUCT_LABELS: Record<ProductType, string> = {
  fresh: "Gmail Fresh",
  bekas: "Gmail Bekas",
};

/** Human-readable labels for order statuses. */
export const ORDER_STATUS_LABELS: Record<OrderStatus, string> = {
  pendingPayment: "Menunggu Pembayaran",
  paid: "Dibayar",
  delivered: "Terkirim",
};
