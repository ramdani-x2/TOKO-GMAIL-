import {
  type ExternalBlob,
  type OrderView,
  type Product,
  type ProductType,
  UserRole,
  createActor,
} from "@/backend";
import { useActor } from "@caffeineai/core-infrastructure";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

/** Convert a backend nanosecond timestamp to a JS Date (or null when invalid). */
export function timestampToDate(timestamp: bigint): Date | null {
  const date = new Date(Number(timestamp / 1_000_000n));
  return Number.isNaN(date.getTime()) ? null : date;
}

/** All products (Gmail Fresh / Gmail Bekas) with their prices. */
export function useProducts() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery({
    queryKey: ["products"],
    queryFn: async (): Promise<Product[]> => {
      if (!actor) return [];
      return actor.getProducts();
    },
    enabled: !!actor && !isFetching,
  });
}

/** Current stock counts per product type. */
export function useStockCounts() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery({
    queryKey: ["stockCounts"],
    queryFn: async (): Promise<Array<[ProductType, bigint]>> => {
      if (!actor) return [];
      return actor.getStockCounts();
    },
    enabled: !!actor && !isFetching,
  });
}

/** The merchant QRIS configuration string. */
export function useQrisConfig() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery({
    queryKey: ["qrisConfig"],
    queryFn: async (): Promise<string> => {
      if (!actor) return "";
      return actor.getQrisConfig();
    },
    enabled: !!actor && !isFetching,
  });
}

/** Create a new order for a buyer. */
export function useCreateOrder() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (input: {
      buyerName: string;
      buyerContact: string;
      productType: ProductType;
      quantity: bigint;
    }): Promise<OrderView> => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.createOrder(
        input.buyerName,
        input.buyerContact,
        input.productType,
        input.quantity,
      );
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["stockCounts"] });
    },
  });
}

/** Fetch a single order by its order number. */
export function useGetOrder(orderNumber: string | null) {
  const { actor, isFetching } = useActor(createActor);
  return useQuery({
    queryKey: ["order", orderNumber],
    queryFn: async (): Promise<OrderView | null> => {
      if (!actor || !orderNumber) return null;
      return actor.getOrder(orderNumber);
    },
    enabled: !!actor && !isFetching && !!orderNumber,
  });
}

/** Confirm payment for an order, releasing the Gmail account. */
export function useConfirmPayment() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (orderNumber: string): Promise<OrderView | null> => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.confirmPayment(orderNumber);
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["orders"] });
      void queryClient.invalidateQueries({ queryKey: ["stockCounts"] });
    },
  });
}

/** Mark an order as delivered (admin). */
export function useDeliverOrder() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (orderNumber: string): Promise<OrderView | null> => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.deliverOrder(orderNumber);
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["orders"] });
    },
  });
}

/** Add a Gmail account to stock (admin). */
export function useAddGmailAccount() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (input: {
      productType: ProductType;
      email: string;
      password: string;
    }): Promise<bigint> => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.addGmailAccount(
        input.productType,
        input.email,
        input.password,
      );
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["stockCounts"] });
    },
  });
}

/** Delete a Gmail account from stock (admin). */
export function useDeleteGmailAccount() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (input: {
      productType: ProductType;
      accountId: bigint;
    }): Promise<boolean> => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.deleteGmailAccount(input.productType, input.accountId);
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["stockCounts"] });
    },
  });
}

/** Update the merchant QRIS configuration (admin). */
export function useSetQrisConfig() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (code: string): Promise<void> => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.setQrisConfig(code);
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["qrisConfig"] });
    },
  });
}

/** The uploaded QRIS image (ExternalBlob) configured by the admin. */
export function useQrisImage() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery({
    queryKey: ["qrisImage"],
    queryFn: async (): Promise<ExternalBlob | null> => {
      if (!actor) return null;
      return actor.getQrisImage();
    },
    enabled: !!actor && !isFetching,
  });
}

/** Upload and store the QRIS image (admin). */
export function useSetQrisImage() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (image: ExternalBlob): Promise<void> => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.setQrisImage(image);
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["qrisImage"] });
    },
  });
}

/** All orders (admin). */
export function useOrders() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery({
    queryKey: ["orders"],
    queryFn: async (): Promise<OrderView[]> => {
      if (!actor) return [];
      return actor.getOrders();
    },
    enabled: !!actor && !isFetching,
  });
}

/** Whether the current caller is an admin. */
export function useIsCallerAdmin() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery({
    queryKey: ["isCallerAdmin"],
    queryFn: async (): Promise<boolean> => {
      if (!actor) return false;
      return actor.isCallerAdmin();
    },
    enabled: !!actor && !isFetching,
  });
}

/** The current caller's role. */
export function useCallerUserRole() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery({
    queryKey: ["callerUserRole"],
    queryFn: async (): Promise<UserRole> => {
      if (!actor) return UserRole.guest;
      return actor.getCallerUserRole();
    },
    enabled: !!actor && !isFetching,
  });
}
