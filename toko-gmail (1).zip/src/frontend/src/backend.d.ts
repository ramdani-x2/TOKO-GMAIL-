import type { Principal } from "@icp-sdk/core/principal";
export interface Some<T> {
    __kind__: "Some";
    value: T;
}
export interface None {
    __kind__: "None";
}
export type Option<T> = Some<T> | None;
import type { ExternalBlob } from "@caffeineai/object-storage";
export type { ExternalBlob } from "@caffeineai/object-storage";
export type Result__1 = {
    __kind__: "ok";
    ok: null;
} | {
    __kind__: "err";
    err: Error_;
};
export type Error_ = {
    __kind__: "FrontendOriginsNotConfigured";
    FrontendOriginsNotConfigured: null;
} | {
    __kind__: "MixedSsoSources";
    MixedSsoSources: {
        otherKeys: Array<string>;
        ssoKeys: Array<string>;
    };
} | {
    __kind__: "Stale";
    Stale: {
        ageNs: bigint;
    };
} | {
    __kind__: "MalformedCandid";
    MalformedCandid: null;
} | {
    __kind__: "AmbiguousAttribute";
    AmbiguousAttribute: {
        field: string;
        sources: Array<string>;
    };
} | {
    __kind__: "NoAttributes";
    NoAttributes: null;
} | {
    __kind__: "UnknownNonce";
    UnknownNonce: null;
} | {
    __kind__: "UntrustedSsoSource";
    UntrustedSsoSource: {
        domain: string;
    };
} | {
    __kind__: "MissingField";
    MissingField: string;
} | {
    __kind__: "FrontendOriginMismatch";
    FrontendOriginMismatch: {
        got: string;
        expected: Array<string>;
    };
};
export interface Result {
    hasMore: boolean;
    rows: Array<Array<Cell>>;
}
export interface Cell {
    value: Value;
    name: string;
}
export type Value = {
    __kind__: "int";
    int: bigint;
} | {
    __kind__: "nat";
    nat: bigint;
} | {
    __kind__: "float";
    float: number;
} | {
    __kind__: "bool";
    bool: boolean;
} | {
    __kind__: "null";
    null: null;
} | {
    __kind__: "text";
    text: string;
};
export interface Product {
    productType: ProductType;
    price: bigint;
}
export interface OrderView {
    status: OrderStatus;
    deliveredAccount?: string;
    createdAt: bigint;
    productType: ProductType;
    buyerContact: string;
    quantity: bigint;
    buyerName: string;
    totalPrice: bigint;
    orderNumber: string;
}
export enum OrderStatus {
    paid = "paid",
    pendingPayment = "pendingPayment",
    delivered = "delivered"
}
export enum ProductType {
    fresh = "fresh",
    bekas = "bekas"
}
export enum UserRole {
    admin = "admin",
    user = "user",
    guest = "guest"
}
export interface backendInterface {
    addGmailAccount(productType: ProductType, email: string, password: string): Promise<bigint>;
    assignCallerUserRole(user: Principal, role: UserRole): Promise<void>;
    confirmPayment(orderNumber: string): Promise<OrderView | null>;
    createOrder(buyerName: string, buyerContact: string, productType: ProductType, quantity: bigint): Promise<OrderView>;
    deleteGmailAccount(productType: ProductType, accountId: bigint): Promise<boolean>;
    deliverOrder(orderNumber: string): Promise<OrderView | null>;
    execute(qJson: string): Promise<Result>;
    getCallerUserRole(): Promise<UserRole>;
    getOrder(orderNumber: string): Promise<OrderView | null>;
    getOrders(): Promise<Array<OrderView>>;
    getProducts(): Promise<Array<Product>>;
    getQrisConfig(): Promise<string>;
    getQrisImage(): Promise<ExternalBlob | null>;
    getStockCounts(): Promise<Array<[ProductType, bigint]>>;
    isCallerAdmin(): Promise<boolean>;
    schema(): Promise<string>;
    setQrisConfig(code: string): Promise<void>;
    setQrisImage(image: ExternalBlob): Promise<void>;
}
