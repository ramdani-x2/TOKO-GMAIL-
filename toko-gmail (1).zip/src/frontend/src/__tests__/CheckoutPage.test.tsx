import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { beforeEach, describe, expect, it, vi } from "vitest";

import { OrderStatus, ProductType } from "@/backend";
import type { OrderView, Product } from "@/backend";
import { CheckoutPage } from "@/pages/CheckoutPage";
import { ExternalBlob } from "@caffeineai/object-storage";

// Mock the infrastructure hooks that talk to the actor and auth.
const actorMock = vi.hoisted(() => ({
  getQrisConfig: vi.fn(),
  getQrisImage: vi.fn(),
  getProducts: vi.fn(),
  createOrder: vi.fn(),
  getOrder: vi.fn(),
}));

vi.mock("@caffeineai/core-infrastructure", () => ({
  useActor: () => ({ actor: actorMock, isFetching: false }),
  useInternetIdentity: () => ({
    isAuthenticated: true,
    isInitializing: false,
    isLoggingIn: false,
    login: vi.fn(),
    clear: vi.fn(),
    loginStatus: "success",
    isLoginIdle: false,
    isLoginSuccess: true,
    isLoginError: false,
  }),
}));

// The object-storage package ships a broken ESM build (extensionless relative
// import) that fails to resolve under Vitest. It is only used as a type by the
// generated backend wrapper, so a stub is sufficient for these component tests.
vi.mock("@caffeineai/object-storage", () => ({
  ExternalBlob: class ExternalBlob {
    directURL: string;
    constructor(url = "") {
      this.directURL = url;
    }
    static fromURL(_url: string) {
      return new ExternalBlob(_url);
    }
    static fromBytes() {
      return new ExternalBlob();
    }
    getDirectURL() {
      return this.directURL;
    }
  },
}));

vi.mock("@tanstack/react-router", async (importOriginal) => {
  const actual =
    await importOriginal<typeof import("@tanstack/react-router")>();
  return {
    ...actual,
    useSearch: () => ({}),
  };
});

const PRODUCTS: Product[] = [
  { productType: ProductType.fresh, price: 6000n },
  { productType: ProductType.bekas, price: 3000n },
];

function renderCheckout() {
  const queryClient = new QueryClient({
    defaultOptions: { queries: { retry: false } },
  });
  return render(
    <QueryClientProvider client={queryClient}>
      <CheckoutPage />
    </QueryClientProvider>,
  );
}

describe("CheckoutPage QRIS rendering", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    actorMock.getProducts.mockResolvedValue(PRODUCTS);
    actorMock.getOrder.mockResolvedValue(null);
    actorMock.getQrisImage.mockResolvedValue(null);
  });

  it("renders an <img> when the QRIS config is a data:image URL", async () => {
    actorMock.getQrisConfig.mockResolvedValue(
      "data:image/png;base64,iVBORw0KGgoAAAANSUhEUg==",
    );

    renderCheckout();

    // Fill the buyer form and submit to reach the payment panel.
    await userEvent.type(screen.getByLabelText("Nama Lengkap"), "Budi Santoso");
    await userEvent.type(
      screen.getByLabelText("Kontak (WhatsApp / Email)"),
      "081234567890",
    );
    actorMock.createOrder.mockResolvedValue({
      orderNumber: "ORD-1",
      buyerName: "Budi Santoso",
      buyerContact: "081234567890",
      productType: ProductType.fresh,
      quantity: 1n,
      totalPrice: 6000n,
      status: OrderStatus.pendingPayment,
      createdAt: 0n,
    } satisfies OrderView);

    await userEvent.click(screen.getByRole("button", { name: "Buat Pesanan" }));

    const img = await screen.findByTestId("checkout.qris_image");
    expect(img).toHaveAttribute(
      "src",
      "data:image/png;base64,iVBORw0KGgoAAAANSUhEUg==",
    );
    expect(img).toHaveAttribute("alt", "Kode QRIS merchant untuk pembayaran");
  });

  it("renders the uploaded QRIS image when one is configured", async () => {
    actorMock.getQrisConfig.mockResolvedValue("");
    actorMock.getQrisImage.mockResolvedValue(
      ExternalBlob.fromURL("https://cdn.example.com/qris.png"),
    );

    renderCheckout();

    // Fill the buyer form and submit to reach the payment panel.
    await userEvent.type(screen.getByLabelText("Nama Lengkap"), "Budi Santoso");
    await userEvent.type(
      screen.getByLabelText("Kontak (WhatsApp / Email)"),
      "081234567890",
    );
    actorMock.createOrder.mockResolvedValue({
      orderNumber: "ORD-IMG",
      buyerName: "Budi Santoso",
      buyerContact: "081234567890",
      productType: ProductType.fresh,
      quantity: 1n,
      totalPrice: 6000n,
      status: OrderStatus.pendingPayment,
      createdAt: 0n,
    } satisfies OrderView);

    await userEvent.click(screen.getByRole("button", { name: "Buat Pesanan" }));

    const img = await screen.findByTestId("checkout.qris_image");
    expect(img).toHaveAttribute("src", "https://cdn.example.com/qris.png");
    expect(img).toHaveAttribute("alt", "Kode QRIS merchant untuk pembayaran");
  });

  it("shows the empty state when no QRIS is configured", async () => {
    actorMock.getQrisConfig.mockResolvedValue("");

    renderCheckout();

    await userEvent.type(screen.getByLabelText("Nama Lengkap"), "Budi Santoso");
    await userEvent.type(
      screen.getByLabelText("Kontak (WhatsApp / Email)"),
      "081234567890",
    );
    actorMock.createOrder.mockResolvedValue({
      orderNumber: "ORD-2",
      buyerName: "Budi Santoso",
      buyerContact: "081234567890",
      productType: ProductType.fresh,
      quantity: 1n,
      totalPrice: 6000n,
      status: OrderStatus.pendingPayment,
      createdAt: 0n,
    } satisfies OrderView);

    await userEvent.click(screen.getByRole("button", { name: "Buat Pesanan" }));

    expect(
      await screen.findByText(
        "Kode QRIS merchant belum dikonfigurasi oleh admin.",
      ),
    ).toBeInTheDocument();
  });

  it("renders the QRIS code as text when it is not a data:image URL", async () => {
    // NOTE: this branch is expected to change when image upload lands; it is
    // characterized now to document the current plain-text rendering.
    actorMock.getQrisConfig.mockResolvedValue("000201010212QRISCODE");

    renderCheckout();

    await userEvent.type(screen.getByLabelText("Nama Lengkap"), "Budi Santoso");
    await userEvent.type(
      screen.getByLabelText("Kontak (WhatsApp / Email)"),
      "081234567890",
    );
    actorMock.createOrder.mockResolvedValue({
      orderNumber: "ORD-3",
      buyerName: "Budi Santoso",
      buyerContact: "081234567890",
      productType: ProductType.fresh,
      quantity: 1n,
      totalPrice: 6000n,
      status: OrderStatus.pendingPayment,
      createdAt: 0n,
    } satisfies OrderView);

    await userEvent.click(screen.getByRole("button", { name: "Buat Pesanan" }));

    expect(await screen.findByTestId("checkout.qris_code")).toHaveTextContent(
      "000201010212QRISCODE",
    );
  });
});
