import "@testing-library/jest-dom/vitest";
import { configure } from "@testing-library/react";

// Generated components use `data-ocid` instead of `data-testid`.
configure({ testIdAttribute: "data-ocid" });
