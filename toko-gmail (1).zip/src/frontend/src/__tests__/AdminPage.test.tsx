import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { beforeEach, describe, expect, it, vi } from "vitest";

import { AdminPage } from "@/pages/AdminPage";
import { ExternalBlob } from "@caffeineai/object-storage";

// Mock the infrastructure hooks that talk to the actor and auth.
const actorMock = vi.hoisted(() => ({
  getQrisConfig: vi.fn(),
  getQrisImage: vi.fn(),
  setQrisImage: vi.fn(),
  getStockCounts: vi.fn(),
  getOrders: vi.fn(),
  isCallerAdmin: vi.fn(),
}));

vi.mock("@caffeineai/core-infrastructure", () => ({
  useActor: () => ({ actor: actorMock, isFetching: false }),
  useInternetIdentity: () => ({
    isAuthenticated: true,
    isInitializing: false,
    isLoggingIn: false,
    login: vi.fn(),
    clear: vi.fn(),
    loginStatus: "success",
    isLoginIdle: false,
    isLoginSuccess: true,
    isLoginError: false,
  }),
}));

// The object-storage package ships a broken ESM build (extensionless relative
// import) that fails to resolve under Vitest. It is only used as a type by the
// generated backend wrapper, so a stub is sufficient for these component tests.
vi.mock("@caffeineai/object-storage", () => ({
  ExternalBlob: class ExternalBlob {
    directURL: string;
    constructor(url = "") {
      this.directURL = url;
    }
    static fromURL(_url: string) {
      return new ExternalBlob(_url);
    }
    static fromBytes() {
      return new ExternalBlob();
    }
    getDirectURL() {
      return this.directURL;
    }
  },
}));

function renderAdmin() {
  const queryClient = new QueryClient({
    defaultOptions: { queries: { retry: false } },
  });
  return render(
    <QueryClientProvider client={queryClient}>
      <AdminPage />
    </QueryClientProvider>,
  );
}

describe("AdminPage QRIS section", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    actorMock.getStockCounts.mockResolvedValue([]);
    actorMock.getOrders.mockResolvedValue([]);
    actorMock.isCallerAdmin.mockResolvedValue(true);
    actorMock.getQrisImage.mockResolvedValue(null);
    actorMock.setQrisImage.mockResolvedValue(undefined);
  });

  it("shows the QRIS section with a save control for an admin", async () => {
    actorMock.getQrisConfig.mockResolvedValue("");

    renderAdmin();

    expect(await screen.findByTestId("admin_qris_section")).toBeInTheDocument();
    expect(
      screen.getByRole("button", { name: "Simpan Kode QRIS" }),
    ).toBeInTheDocument();
  });

  it("shows 'Belum diatur' for both code and image when nothing is configured", async () => {
    actorMock.getQrisConfig.mockResolvedValue("");

    renderAdmin();

    expect(await screen.findAllByText("Belum diatur")).toHaveLength(2);
  });

  it("shows the current QRIS code when one is configured", async () => {
    actorMock.getQrisConfig.mockResolvedValue("000201010212QRISCODE");

    renderAdmin();

    expect(await screen.findByText("000201010212QRISCODE")).toBeInTheDocument();
  });

  it("provides a file upload control for the QRIS image", async () => {
    actorMock.getQrisConfig.mockResolvedValue("");

    renderAdmin();

    const input = await screen.findByTestId("admin_qris_image_input");
    expect(input).toHaveAttribute("type", "file");
    expect(input).toHaveAttribute("accept", "image/png,image/jpeg");
  });

  it("uploads a selected image file through setQrisImage", async () => {
    actorMock.getQrisConfig.mockResolvedValue("");

    renderAdmin();

    const file = new File(["fake-image-bytes"], "qris.png", {
      type: "image/png",
    });
    // jsdom's File lacks arrayBuffer(); provide it so handleUpload can read it.
    Object.defineProperty(file, "arrayBuffer", {
      value: async () => new ArrayBuffer(8),
    });
    const input = await screen.findByTestId("admin_qris_image_input");
    await userEvent.upload(input, file);

    await waitFor(() => {
      expect(actorMock.setQrisImage).toHaveBeenCalledTimes(1);
    });
    const blob = actorMock.setQrisImage.mock.calls[0][0];
    expect(blob).toBeInstanceOf(ExternalBlob);
  });

  it("shows the uploaded QRIS image preview when one is configured", async () => {
    actorMock.getQrisConfig.mockResolvedValue("");
    actorMock.getQrisImage.mockResolvedValue(
      ExternalBlob.fromURL("https://cdn.example.com/qris.png"),
    );

    renderAdmin();

    const img = await screen.findByTestId("admin_qris_image_preview");
    expect(img).toHaveAttribute("src", "https://cdn.example.com/qris.png");
    expect(img).toHaveAttribute("alt", "Kode QRIS merchant untuk pembayaran");
  });
});
