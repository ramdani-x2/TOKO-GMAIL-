import { createIdentity, PocketIc } from "@dfinity/pic";
import { afterAll, beforeAll, expect, it } from "vitest";

import { idlFactory } from "../../src/frontend/src/declarations/backend.did.js";
import type { _SERVICE } from "../../src/frontend/src/declarations/backend.did";

const PIC_URL = process.env.POCKET_IC_URL ?? "";
const BACKEND_WASM = process.env.BACKEND_WASM ?? "";
// Set only on a converted project: the last pre-EM revision, whose schema this
// app's migration chain replays from. Installing the current wasm onto an empty
// canister there traps IC0503 before any test runs.
const BASELINE_WASM = process.env.BACKEND_WASM_BASELINE;

// The first caller to sign in becomes the admin, so the installing principal is
// the owner that admin-only methods (setQrisConfig, setQrisImage) accept.
const adminIdentity = createIdentity("qris-admin-seed");
const ADMIN = adminIdentity.getPrincipal();
const nonAdminIdentity = createIdentity("qris-non-admin-seed");

let pic: PocketIc | undefined;
let actor: _SERVICE;

beforeAll(async () => {
  pic = await PocketIc.create(PIC_URL);
  if (BASELINE_WASM === undefined) {
    ({ actor } = await pic.setupCanister<_SERVICE>({
      idlFactory,
      wasm: BACKEND_WASM,
      sender: ADMIN,
    }));
  } else {
    // `[baseline, current]`, the same install contract the hosted deploy uses
    // for a converted project. The upgrade replays the chain from the legacy
    // schema.
    const installed = await pic.setupCanister<_SERVICE>({
      idlFactory,
      wasm: BASELINE_WASM,
      sender: ADMIN,
    });
    await pic.upgradeCanister({ canisterId: installed.canisterId, wasm: BACKEND_WASM, arg: new Uint8Array() });
    actor = installed.actor;
  }
  // The first caller to sign in becomes the admin. Assign it explicitly here so
  // every test can rely on ADMIN being the admin regardless of run order.
  actor.setIdentity(adminIdentity);
  await actor._initialize_access_control();
});

afterAll(async () => {
  // `?.` because `beforeAll` may not have got that far. A failed
  // `PocketIc.create` otherwise stacks "Cannot read properties of undefined"
  // on top of the real error and buries the one line that explains the run.
  await pic?.tearDown();
});

it("answers an empty-state QRIS read instead of trapping", async () => {
  await expect(actor.getQrisConfig()).resolves.toBe("");
  await expect(actor.getQrisImage()).resolves.toEqual([]);
});

it("round-trips the QRIS text code through the real canister", async () => {
  actor.setIdentity(adminIdentity);
  await actor.setQrisConfig("000201010212QRISCODE");
  await expect(actor.getQrisConfig()).resolves.toBe("000201010212QRISCODE");
});

it("round-trips the QRIS image bytes through the real canister", async () => {
  actor.setIdentity(adminIdentity);
  const image = new Uint8Array([1, 2, 3, 4, 5]);
  await actor.setQrisImage(image);
  await expect(actor.getQrisImage()).resolves.toEqual([image]);
});

it("rejects a non-admin caller from setting the QRIS image", async () => {
  actor.setIdentity(nonAdminIdentity);
  await expect(actor.setQrisImage(new Uint8Array([9]))).rejects.toThrow();
});
