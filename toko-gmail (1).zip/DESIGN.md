# Design Brief

## Direction

Segar — a fresh, trustworthy Indonesian e-commerce storefront for selling Gmail accounts (Fresh Rp6.000, Bekas Rp3.000) with instant delivery via QRIS.

## Tone

Clean, product-focused, modern e-commerce with a fresh green identity that signals "instant, reliable, ready-to-use" — trustworthy and frictionless for a payment flow.

## Differentiation

A green-and-amber dual-product palette that visually separates "Gmail Fresh" (fresh green) from "Gmail Bekas" (warm amber), making the two price points instantly scannable and memorable.

## Color Palette

| Token      | OKLCH          | Role                                    |
| ---------- | -------------- | --------------------------------------- |
| background | 0.985 0.006 160 | mint-tinted off-white page surface      |
| foreground | 0.22 0.02 170  | deep green-black text                   |
| card       | 1.0 0.004 160  | elevated product/checkout surfaces      |
| primary    | 0.52 0.15 160  | fresh green — CTAs, Gmail Fresh brand   |
| accent     | 0.72 0.14 75   | warm amber — Gmail Bekas brand          |
| muted      | 0.955 0.012 160| soft section/benefit strip background   |
| success    | 0.6 0.16 150   | payment-confirmed / delivered states    |

## Typography

- Display: Space Grotesk — hero headline, product names, section headings
- Body: DM Sans — paragraphs, labels, buttons, form fields
- Scale: hero `text-4xl md:text-6xl font-bold tracking-tight`, h2 `text-2xl md:text-4xl font-bold tracking-tight`, label `text-sm font-semibold tracking-widest uppercase`, body `text-base`

## Elevation & Depth

Soft green-tinted elevated shadows on product cards and CTAs lift interactive surfaces off a flat mint background; depth comes from layering, not full-page gradients.

## Structural Zones

| Zone    | Background      | Border   | Notes                                        |
| ------- | --------------- | -------- | -------------------------------------------- |
| Header  | bg-card         | border-b | sticky, logo + admin login link              |
| Hero    | bg-gradient-subtle | —     | bold headline + primary CTA on tinted band   |
| Products| bg-background   | —        | two cards side by side (stack on mobile)     |
| Benefits| bg-muted/40     | border-y | icon trust strip (instan, QRIS, aman)        |
| Footer  | bg-muted/40     | border-t | muted, store links, payment note             |

## Spacing & Rhythm

Mobile-first with generous vertical rhythm (section gaps `py-16 md:py-24`, card padding `p-6 md:p-8`); tight micro-spacing inside cards for price and quantity density.

## Component Patterns

- Buttons: rounded-full pills; primary green for "Beli Sekarang", amber for Gmail Bekas; hover darkens + shadow-elevated
- Cards: `rounded-2xl` (24px), bg-card, shadow-elevated, subtle hover lift
- Badges: rounded-full pill chips; green "Fresh" / amber "Bekas" / success "Terkirim"

## Motion

- Entrance: `animate-fade-up` staggered on hero and product cards (0.5s ease-out)
- Hover: smooth lift + shadow transition on cards and buttons (0.3s)
- Decorative: `animate-float` on a subtle brand leaf mark in the hero

## Constraints

- Bahasa Indonesia for all UI copy
- Mobile-first responsive (cards stack, CTAs full-width on small screens)
- Token-only styling — no raw hex/rgb in components
- AA+ contrast in both light and dark; light is the primary mode

## Signature Detail

The green/amber dual-brand color story that lets buyers tell "Fresh" from "Bekas" at a glance, reinforced by matching CTA colors and trust badges.
